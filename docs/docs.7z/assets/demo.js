_$(()=> {
    // Link Cores
    const CORE = '<link rel="stylesheet" href="/assets/vendor.min.css"><script src="/assets/fascinoTs.umd.cjs"></script><script src="/assets/vendor.min.js"></script>';

    var customCompleter = {
        getCompletions: function(editor, session, pos, prefix, callback) {
            var wordList = Object.keys(_$); // Reemplaza con tus propias palabras
            callback(null, wordList.map(function(word) {
                return {
                    caption: word,
                    value: word,
                    meta: "Fascino"
                };
            }));
        }
    };
    ace.require("ace/ext/language_tools").addCompleter(customCompleter);
    var editor = ace.edit("editor", {
        mode: "ace/mode/javascript",
        theme: "ace/theme/monokai",
        highlightActiveLine: true
    })

    editor.setOptions({
        enableBasicAutocompletion: true,
        enableSnippets: true,
        enableLiveAutocompletion: false
    })

    function runCode() {
        var userCode = editor.getValue();
        var sandboxFrame = _$("#areasand").first
        var sandboxDoc = sandboxFrame.contentDocument || 
            sandboxFrame.contentWindow.document;
        sandboxDoc.open()
        sandboxDoc.write(CORE + '<script>'+ userCode + '</script>');
        sandboxDoc.close()
    }
    runCode()
    editor.session.on('change', runCode);
    _$(window).on("resize", function(){
        editor.resize()
    })
})