_$(() => {
    console.log(`
Bienvenido a ${_$().name} V ${_$().version}
`)


})